package com.example.businesscard

import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.businesscard.ui.theme.BusinessCardTheme

private val Ink = Color(0xFF102A56)
private val Accent = Color(0xFFB91C32)
private val Paper = Color(0xFFF4F7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            BusinessCardTheme {
                BusinessCard(modifier = Modifier.fillMaxSize())
            }
        }
    }
}

// Like the Postcard example, a Column arranges Text and Image composables.
@Composable
fun BusinessCard(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.background(Color(0xFF123D85)).safeDrawingPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(3.dp, Accent),
                colors = CardDefaults.cardColors(containerColor = Paper)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(R.drawable.peter_parker),
                        contentDescription = stringResource(R.string.portrait_description),
                        modifier = Modifier.size(132.dp).clip(RoundedCornerShape(16.dp))
                    )
                    Spacer(Modifier.height(24.dp))
                    Text(
                        text = stringResource(R.string.person_name), color = Ink,
                        fontSize = 32.sp, lineHeight = 38.sp,
                        fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.person_role), color = Accent,
                        fontSize = 16.sp, lineHeight = 24.sp,
                        fontWeight = FontWeight.Medium, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.organization),
                        color = Color(0xFF455A7A), fontSize = 14.sp,
                        lineHeight = 20.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(28.dp))
                    HorizontalDivider(color = Color(0xFFE7B3BF))
                    Spacer(Modifier.height(24.dp))
                    Text(
                        text = stringResource(R.string.email_label), color = Accent,
                        fontSize = 11.sp, letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.person_email), color = Ink,
                        fontSize = 16.sp, lineHeight = 24.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true, widthDp = 412, heightDp = 892)
@Composable
fun BusinessCardPreview() {
    BusinessCardTheme { BusinessCard(Modifier.fillMaxSize()) }
}

@Preview(showBackground = true, widthDp = 640, heightDp = 360, fontScale = 1.3f)
@Composable
fun BusinessCardLandscapePreview() {
    BusinessCardTheme { BusinessCard(Modifier.fillMaxSize()) }
}
